app.directive("movieDirective",function(){
    return {        
        templateUrl : "../movieCard.html",
        restrict : "EAC"
    };
});