//@ts-check
var app = angular.module("angularTemplatesApp",[]);