function calcPow(){
    var i=5;
    document.getElementById("power").innerHTML=i*i;
}

function calcMod(){
    var i = 100;
    var j=8;
    window.alert(i%j);
}

function concatStr()
{
    var hellow = 'hello';

    var world = 'world';
    
    console.log(hellow +' ' +world);
}