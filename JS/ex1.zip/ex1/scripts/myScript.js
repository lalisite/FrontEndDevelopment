function changePlaneImage(){
    document.getElementById("plane-image").src="https://static.wixstatic.com/media/2f17db_ac1f2c282cdf4881baf37bb78fb7c309~mv2_d_1500_1500_s_2.jpg/v1/fill/w_500,h_500,q_85,usm_0.66_1.00_0.01/2f17db_ac1f2c282cdf4881baf37bb78fb7c309~mv2_d_1500_1500_s_2.jpg";
}

function changeHeadingText(){
    document.getElementById("heading1").innerHTML="This is a different plane";
}

function changeBackgroundColor(){
    document.getElementById("body").style.backgroundColor="blue";
}

