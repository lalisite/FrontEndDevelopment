
var app = angular.module("myCalculatorApp",[]);
