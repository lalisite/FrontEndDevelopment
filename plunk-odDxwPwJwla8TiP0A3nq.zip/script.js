// Code goes here
function addItem(){
  var ul = document.getElementById("itemsList");
  var li = document.createElement("li");
  var newItem = document.getElementById("inputItem").value;
  li.appendChild(document.createTextNode(newItem));
  ul.appendChild(li);
  var numberOfItems = document.getElementById("itemsList").getElementsByTagName("li").length
  if(numberOfItems > 6){
    document.getElementById("addButton").disabled = true; 
  }
  else{
    document.getElementById("addButton").disabled = false; 
  }
  
}